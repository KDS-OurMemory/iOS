//
//  OurMemoryTask.h
//  OurMemoryTask
//
//  Created by 이승기 on 2021/02/26.
//

#import <Foundation/Foundation.h>

//! Project version number for OurMemoryTask.
FOUNDATION_EXPORT double OurMemoryTaskVersionNumber;

//! Project version string for OurMemoryTask.
FOUNDATION_EXPORT const unsigned char OurMemoryTaskVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OurMemoryTask/PublicHeader.h>


